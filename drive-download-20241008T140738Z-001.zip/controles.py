import parametros
def controles_planeio():
    F=0;phi=0;Y=0
    CL=parametros.CL
    return CL,F,phi,Y
